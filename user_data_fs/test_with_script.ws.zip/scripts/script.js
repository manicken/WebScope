({
    /** Runs when you press Run. ws: the capture, the decoders and save(), see README "Scripts". */
    run(ws) {
        // e.g. every decoder's annotations as CSV
        const rows = [['decoder', 'row', 'start (s)', 'end (s)', 'text']];
        for (const d of ws.decoders) {
            for (const [row, anns] of Object.entries(d.annotations)) {
                for (const a of anns) rows.push([d.name, row, a.startTime, a.endTime, a.text]);
            }
        }
        ws.log(`${rows.length - 1} annotations`);
        return ws.save('annotations.csv', ws.csv(rows));
    },
})
